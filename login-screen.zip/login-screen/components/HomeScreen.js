import React from 'react';
import { View, Image, TouchableOpacity, StyleSheet } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      {/* FaceID Button */}
      <TouchableOpacity onPress={() => navigation.navigate('FaceId')}>
        <Image
          source={require('../assets/FaceID.png')}  // Ensure this path is correct
          style={styles.image}
        />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: 100,  // Adjust size based on your design
    height: 100, // Adjust size based on your design
  },
});

export default HomeScreen;
